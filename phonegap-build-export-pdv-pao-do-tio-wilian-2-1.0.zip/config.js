define( function ( require ) {

	"use strict";

	return {
		app_slug : 'pdv-pao-do-tio-wilian-2',
		wp_ws_url : 'https://www.paodotiowilian.com.br/wp-appkit-api/pdv-pao-do-tio-wilian-2',
		wp_url : 'https://www.paodotiowilian.com.br',
		theme : 'q-android',
		version : '1.0',
		app_type : 'phonegap-build',
		app_title : 'PDV - Pão do tio Wilian',
		app_platform : 'android',
		app_path: '',
		gmt_offset : -3,
		debug_mode : 'off',
		auth_key : 'R4,i_hUfS7emI(BIB~1?G5I$v?Cu4@tYu=Xo$cR,fppH*Qa0R{ .|[UyGljN@a<s',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
